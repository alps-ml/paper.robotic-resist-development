# Security Policy

## Reporting a Vulnerability

To report a security issue, please contact the owners of the repository at https://github.com/theteamatx/x-edr-rrtconnect
with a description of the issue, the steps you took to create the issue, affected versions, and,
if known, mitigations for the issue.
